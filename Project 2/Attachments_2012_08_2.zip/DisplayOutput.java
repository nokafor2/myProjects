
public class DisplayOutput {

	public static void main(String[] args) {


	}
	
	class DisplayOutputThread implements Runnable{
		public void run() {
			
			
		}
		
		
	}

}
