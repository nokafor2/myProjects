import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.List;


public class InputControl implements ActionListener{
	public int intInput;
	public void actionPerformed(ActionEvent e) {
		MostOccurredInteger integerClass = new MostOccurredInteger();
		
	}

}
