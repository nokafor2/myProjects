import java.awt.*;
import javax.swing.*;

public class CarControl extends JFrame {
	public CarControl(){
		
	}
	public static void main(String[] args) {
		CarControl frame = new CarControl();
//		frame.setTitle(")

	}

}
